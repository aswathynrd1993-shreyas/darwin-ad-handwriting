# DARWIN handwriting – leakage-safe nested cross-validation

Code and outputs for the revised manuscript BSPC-D-26-11942.

## Data
Download `data.csv` from the UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/732/darwin (DOI 10.24432/C55D0K).
Expected: 174 rows, 452 columns (ID, 450 features, class with P/H).

## Run
```
pip install numpy pandas scipy scikit-learn matplotlib
python darwin_nested_cv.py data.csv results      # ~12 min on 2 CPU cores
python extra_figs.py data.csv results           # Fig. 1 (correlation) and Fig. 2 (pipeline)
python graphical_abstract.py results/results.json Graphical_Abstract.png
```
Random seed 42 fixes all fold assignments, so re-running reproduces every number.

## Protocol
- Outer: stratified 5-fold CV repeated 5 times (25 outer folds) – evaluation only.
- Inner: stratified 5-fold CV on the outer-training part – grid search over K-FFS size and hyperparameters (scoring ROC-AUC).
- Pipeline (refitted inside every training split): signed-log transform → K-FFS (Fisher score, k = 5, Th = 0.8, n_top ∈ {20, 50, 100}) → StandardScaler (LR only) → classifier.
- Models: LogisticRegression (C ∈ {0.01, 0.1, 1, 10}), RandomForest (300 trees; max_features ∈ {sqrt, 0.2}; min_samples_leaf ∈ {1, 3}), HistGradientBoosting (200 iterations; learning_rate ∈ {0.03, 0.1}; max_depth ∈ {2, 3}); ENS = mean of the three probabilities.

## Output files (`results/`)
| File | Content |
|---|---|
| results.json | dataset summary, fold-level mean/SD, pooled out-of-fold metrics, bootstrap 95% CIs, per-repeat confusion matrices, calibration, feature-selection stability |
| fold_level_metrics.csv | every metric and TP/TN/FP/FN for each model × 25 outer folds |
| oof_probabilities_mean_over_repeats.csv | out-of-fold AD probability per participant (mean of 5 repeats) |
| pairwise_significance.csv | corrected resampled t-tests and McNemar tests |
| per_fold_selected_features_and_hyperparameters.csv | selected hyperparameters and selected features in each outer fold |
| feature_selection_and_importance.csv | selection frequency, permutation importance (mean, SD), top-10 frequency per feature |
| taskwise_results.csv | single-task models: mean ± SD accuracy and AUC |
| fig_*.png | manuscript figures |

## Optional: XGBoost, SHAP and LIME
`darwin_colab_xgb_shap_lime.py` runs the same nested protocol with XGBoost tuned by Optuna in the inner loop, SHAP (TreeExplainer, outer-training background) per outer fold, and LIME stability across 5 seeds. Run it in Google Colab (`pip install xgboost optuna shap lime`).
